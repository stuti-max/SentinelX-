# SentinelX — Cloud Security Operations Dashboard

> **Enterprise SOC & Cloud-Native Security Monitoring Console**  
> *Academic Capstone Project & Portfolio Demonstration*

SentinelX is a cloud security operations dashboard designed to monitor cloud-native infrastructure, visualize security event telemetry, and facilitate incident response triage.

Built with **React 18**, **TypeScript**, **Vite**, **Tailwind CSS**, and **Recharts**, SentinelX connects to a **Node.js/Express REST API** and **Redis** rate-limiting backend deployed on **Azure Kubernetes Service (AKS)** with **Azure Monitor** telemetry.

---

## 🛡️ Project Disclaimer

> [!NOTE]  
> **Simulation & Monitoring Demo**: SentinelX is designed for demonstration, educational, and architectural evaluation purposes. Security events (such as SQL injection probes, brute-force attempts, SSRF queries, and rate-limit spikes) are synthetically generated to model Security Operations Center (SOC) workflows and validate telemetry pipelines. SentinelX does not claim to detect or mitigate real-world cyberattacks without integration into production SIEM/WAF infrastructure.

---

## 🎨 Design System & Aesthetic (Soft Pink & White)

- **Color Palette**: Very pale baby-pink canvas (`#FFF7FB`), clean white cards (`#FFFFFF`) with subtle pink borders (`#FCE7F3` / `#FBCFE8`), and soft shadows.
- **Accents & Navigation**: Rose pink (`#E879B9`) for primary CTA buttons, chart highlights, active navigation states, and selected pills.
- **Typography & Headings**: Deep plum (`#6B3157`) for headings, brand identity, and important text; readable plum-neutral shades (`#835372`) for body text and labels ensuring high contrast and WCAG accessibility.
- **Restrained Functional Colors**: Red (`#E11D48`) for critical security alerts, amber (`#D97706` / `#EA580C`) for warnings and medium severities, and green (`#059669` / `#10B981`) for healthy infrastructure status and SLA compliance.
- **Telemetry Distinction**: Clear visual badges distinguish **Simulated Security Data** (`⚡ purple tag`) from **Infrastructure Telemetry** (`🖥️ rose-pink tag`).
- **Typography**: High-legibility modern sans-serif (`Inter`) paired with monospace font (`JetBrains Mono`) for IPs, status codes, timestamps, and payloads.
- **Responsive Layout**: Minimal, spacious, elegant, and light SOC layout with collapsible navigation sidebar, tablet support, and mobile drawer.

---

## 🚀 Key Features

### 1. Operations Overview
- **6 SOC KPI Metric Cards**:
  - **Total Events**: 24h event ingestion count with trend delta.
  - **Critical Events**: Unmitigated incident count requiring analyst triage.
  - **Requests Per Minute (RPM)**: Edge ingestion throughput.
  - **P95 API Latency**: Milliseconds against a 120ms SLA threshold.
  - **Service Availability**: Trailing 30-day uptime percentage (99.98%).
  - **Active API Replicas**: Kubernetes Horizontal Pod Autoscaler (HPA) state.
- **Timeline Volume Chart**: Multi-series area chart tracking severity distribution over 24 hours.
- **Severity Distribution Donut**: Interactive breakdown of attack severities.
- **HTTP Request Rate & Latency Charts**: RPM throughput with blocked-at-edge ratios and P50/P95/P99 latency trends.
- **Infrastructure Health Panel**: Container health, CPU/memory quotas, uptime, and Redis metrics.
- **Incident Table**: Searchable, filterable event table with relative time formatting.

### 2. Security Events Console
- Real-time incident stream with pill filters (Severity and Status).
- Search by Source IP, Target Endpoint, Event ID, or Rule.
- **Live Event Injection**: Trigger simulated probes in real time to demonstrate live ingestion and counter updates.
- **Interactive Event Inspector**: Slide-over modal showing raw intercepted payloads, HTTP headers, reverse DNS labels, and MITRE ATT&CK technique mappings.
- **Analyst Triage Actions**: Mark incidents as *Mitigated*, *Blocked via Redis ACL*, or *Investigating*.
- Export filtered events to structured JSON.

### 3. Threat Analytics
- **MITRE ATT&CK Mapping**: Visual categorization across Initial Access, Credential Access, Impact, and Defense Evasion.
- **Top 5 Targeted API Endpoints**: Breakdown of probe volume, methods, and WAF block efficiency.
- **Geolocation Threat Origin**: Simulated IP-to-Country distribution.
- **Security Posture Score**: Aggregate defensive posture metric.

### 4. Infrastructure & AKS Cluster
- Node pool status (`Standard_D4s_v5` 3-node cluster).
- Pod replica health across `sentinelx-web`, `sentinelx-api`, `sentinelx-redis`, and `sentinelx-worker`.
- Redis in-memory cache hit rate, memory utilization, and active client connections.
- ACR container image specifications and readiness health checks.

### 5. Settings & API Integration
- Configurable `VITE_API_BASE_URL` with live ping diagnostics.
- Toggle between **Simulated Demo Mode** and **Live REST API Mode**.
- Adjustable background telemetry polling interval.

---

## 📂 Project Structure

```
frontend/
├── public/
│   └── shield.svg                # Application Favicon
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Badge.tsx         # Severity, status, and health badges
│   │   │   ├── EmptyState.tsx    # SOC-styled empty search state
│   │   │   ├── ErrorBanner.tsx   # Network and API error banner with retry
│   │   │   ├── LoadingSpinner.tsx# Pulsing cyber radar spinner
│   │   │   ├── MetricCard.tsx    # High-density KPI stat cards with trend sparklines
│   │   │   └── TelemetryTag.tsx  # Simulated vs Infrastructure distinction badges
│   │   ├── dashboard/
│   │   │   ├── EventsTimeChart.tsx # Recharts 24h AreaChart
│   │   │   ├── InfraHealthPanel.tsx# Pod and Redis health telemetry
│   │   │   ├── KpiGrid.tsx       # 6 core SOC KPIs
│   │   │   ├── LatencyChart.tsx  # P50/P95/P99 LineChart with SLA line
│   │   │   ├── RecentEventsTable.tsx # Searchable, paginated event log table
│   │   │   ├── RequestRateChart.tsx # HTTP RPM BarChart
│   │   │   └── SeverityDonut.tsx # Recharts Pie/Donut chart
│   │   ├── layout/
│   │   │   ├── DisclaimerBanner.tsx # Academic & simulation notice banner
│   │   │   ├── EventDetailModal.tsx # Full incident inspector modal
│   │   │   ├── Sidebar.tsx       # Collapsible navigation drawer
│   │   │   └── Topbar.tsx        # Logo, live clock, env badge, analyst profile
│   │   └── views/
│   │       ├── AnalyticsView.tsx # Threat taxonomy & geo breakdown
│   │       ├── InfrastructureView.tsx # AKS pod & cluster monitoring
│   │       ├── OverviewView.tsx  # Executive operations dashboard
│   │       ├── SecurityEventsView.tsx # Dedicated event hunting console
│   │       └── SettingsView.tsx  # Configuration & API diagnostics
│   ├── context/
│   │   └── DashboardContext.tsx  # Global state, polling, filters, and mutations
│   ├── services/
│   │   ├── api.ts                # Dedicated REST API client & fallback engine
│   │   └── mockData.ts           # Realistic SOC mock data generator
│   ├── styles/
│   │   └── index.css             # Tailwind CSS directives & scrollbar styling
│   ├── types/
│   │   ├── dashboard.ts          # KPI & chart metric interfaces
│   │   ├── security.ts           # Severity, event, and filter types
│   │   └── telemetry.ts          # Service component and cluster telemetry types
│   ├── App.tsx                   # Main application layout & view router
│   ├── main.tsx                  # React entry point
│   └── vite-env.d.ts             # Vite environment typings
├── .env.example                  # Environment configuration template
├── .env                          # Local environment variables
├── index.html                    # Root HTML document
├── package.json                  # Dependencies & npm scripts
├── postcss.config.js             # PostCSS Tailwind setup
├── tailwind.config.js            # SOC color tokens & theme extensions
├── tsconfig.json                 # TypeScript compiler options
└── vite.config.ts                # Vite build and dev server configuration
```

---

## ⚙️ Environment Variables

Create a `.env` file in the `frontend` root based on `.env.example`:

```env
# Backend REST API endpoint (Node.js/Express)
VITE_API_BASE_URL=http://localhost:5000/api/v1

# Enable/disable simulated demo telemetry fallback (true = standalone demo mode)
VITE_ENABLE_DEMO_MODE=true

# Telemetry polling interval in milliseconds
VITE_POLL_INTERVAL_MS=5000

# Cluster environment metadata
VITE_CLUSTER_NAME=aks-sentinelx-eastus2
VITE_CLUSTER_REGION=East US
VITE_K8S_NAMESPACE=sentinelx-soc
```

---

## 🛠️ Getting Started & Local Development

### Prerequisites
- **Node.js**: v18.0.0 or later (v20+ LTS recommended)
- **npm**: v9.0.0 or later

### Installation & Run

1. Navigate to the frontend directory:
   ```bash
   cd frontend
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Launch the Vite development server:
   ```bash
   npm run dev
   ```
   Open your browser at `http://localhost:3000`.

4. Build for production:
   ```bash
   npm run build
   ```

5. Preview the production build locally:
   ```bash
   npm run preview
   ```

---

## 🔌 Backend REST API Integration Contract

When connecting SentinelX to the companion Node.js/Express & Redis backend, implement the following endpoints:

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/health` | Health check endpoint returning `{ status: "ok" }` |
| `GET` | `/metrics/kpis` | Returns the 6 core KPI metric objects |
| `GET` | `/security/events` | Supports query params `q`, `severity`, `status`, `page`, `limit` |
| `PATCH` | `/security/events/:id/status` | Updates event status (`OPEN`, `INVESTIGATING`, `MITIGATED`, `BLOCKED`) |
| `GET` | `/metrics/events-timeline` | Returns 24h event volume points |
| `GET` | `/metrics/severity-distribution` | Returns severity bucket counts and percentages |
| `GET` | `/telemetry/request-rate` | Returns RPM throughput and edge rejection rates |
| `GET` | `/telemetry/latency` | Returns P50, P95, and P99 response times |
| `GET` | `/infrastructure/services` | Returns CPU/Memory/Replica state for Frontend, API, Redis, and Worker |
| `GET` | `/infrastructure/cluster` | Returns AKS node pool and Redis cluster metrics |
| `GET` | `/analytics/summary` | Returns MITRE attack vectors and targeted endpoints |

> [!TIP]  
> If the backend is unreachable or not yet running, SentinelX automatically engages **Simulation Demo Mode** without throwing unhandled exceptions. You can also toggle simulation mode anytime in the top bar or Settings tab.
